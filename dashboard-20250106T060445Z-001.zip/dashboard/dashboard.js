let chartInstance; 

document.addEventListener('DOMContentLoaded', () => {
  const ctx = document.getElementById('onlineOfflineChart').getContext('2d');

  if (chartInstance) {
    chartInstance.destroy(); 
  }

  chartInstance = new Chart(ctx, {
    type: 'line', 
    data: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], 
      datasets: [
        {
          label: 'Online',
          data: [700, 800, 850, 900, 950, 1000, 1100, 1050, 1150, 1200, 1250, 1300], 
          borderColor: '#4caf50', 
          backgroundColor: 'rgba(76, 175, 80, 0.1)', 
          borderWidth: 2,
          tension: 0.3,
          fill: true 
        },
        {
          label: 'Offline',
          data: [500, 550, 600, 650, 700, 750, 800, 850, 900, 950, 1000, 1050], 
          borderColor: '#2196f3', 
          backgroundColor: 'rgba(33, 150, 243, 0.1)', 
          borderWidth: 2,
          tension: 0.3,
          fill: true 
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false, 
      plugins: {
        legend: {
          position: 'top',
          labels: {
            color: '#333',
            font: {
              size: 14
            }
          }
        },
        tooltip: {
          callbacks: {
            label: function (context) {
              return `${context.dataset.label}: ${context.raw}`;
            }
          }
        }
      },
      scales: {
        x: {
          grid: {
            display: false
          },
          ticks: {
            color: '#555'
          }
        },
        y: {
          grid: {
            color: '#eee'
          },
          ticks: {
            color: '#555'
          }
        }
      }
    }
  });
});



const openSidebar = document.getElementById("logo");
const sidebar = document.querySelector('.sidebar');
const mainContent = document.querySelector('.main-content');
const ulText = document.querySelector('.used-space');
const profMail = document.getElementsByClassName("prof-mail");

logo.addEventListener("click", ()=>{
   sidebar.classList.toggle("expanded")

   if(sidebar.classList.contains('expanded')){
    ulText.style.display= flex ;
    profMail.style.display = flex;

   }
})