<?= $this->extend("layouts/app_before") ?>

<?= $this->section("body") ?>

<div class="row m-3">
    <?php if (session()->getFlashdata('response') !== NULL): ?>
        <p style="color:green; font-size:18px;" align="center">
            <?php echo session()->getFlashdata('response'); ?>
        </p>
    <?php endif; ?>

    <?php if (isset($validation)): ?>
        <p style="color:red; font-size:18px;" align="center">
            <?= $validation->showError('validatecheck') ?>
        </p>
    <?php endif; ?>

    <div class="col-md-8 col-sm-12 col-xs-12">
        <!-- <img src="<?php echo base_url(); ?>images/login.png"  class="img-centered img-fluid" alt="login-image"> -->
    </div>
    <div class="col-md-4 col-sm-12 col-xs-12">
        <div class="tab-menus">
            <ul class="nav nav-tabs">
                <li class="active"><a data-toggle="tab" href="#home" class="Login-title">Sign In<span></span></a></li>
                <li><a data-toggle="tab" href="#menu1" class="Login-title">Sign Up<span></span></a></li>
                <!-- <li><a data-toggle="tab" href="#menu2">Menu 2</a></li>
                <li><a data-toggle="tab" href="#menu3">Menu 3</a></li> -->
            </ul>
            <div class="tab-content">
                <div id="home" class="tab-pane show fade in active">
                    <form class="form-Centered sign-in" action="<?= base_url('login') ?>" method="post">
                        <!-- 
                    <h5 class="Login-title">Sign Up</h5> -->
                        <!-- <h6 class="Login-desc">Sign Up and start managing your candidates!</h6> -->
                        <div class="">
                            <label>Tenant Name<label>
                        </div>
                        <div class="mb-3">
                            <input type="text" class="form-control input-style" name="tenantname" id="tenantname"
                                placeholder="Tenant Name" value="<?php echo set_value('tenantname'); ?>">
                            <?php if (isset($validation)): ?>
                                <div style="color:red">
                                    <?= $validation->showError('tenantname') ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="">
                            <label>Email<label>
                        </div>
                        <div class="mb-3">
                            <input type="email" class="form-control input-style" name="email"
                                placeholder="Email Address" id="email" value="<?php echo set_value('email'); ?>">
                            <?php if (isset($validation)): ?>
                                <div style="color:red">
                                    <?= $validation->showError('email') ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="">
                            <label>Password<label>
                        </div>
                        <div class="">
                            <input type="password" class="form-control input-style" name="password" id="password"
                                placeholder="Password">
                            <?php if (isset($validation)): ?>
                                <div style="color:red">
                                    <?= $validation->showError('password') ?>
                                </div>
                            <?php endif; ?>

                        </div>
                        <div class="form-check">
                            <!-- <input type="checkbox" class="form-check-input checkbox-style"> -->
                            <!-- <label class="form-check-label">Remember me</label> -->
                            <label class="form-check-label float-right"> <a class="d-block small mt-3 mb-3"
                                    href="<?php echo site_url('forget'); ?>">Forget Password</a></label>
                        </div>

                        <button type="submit" class="btn btn-primary btn-style Centered">login</button><br>
                        <!-- <a class="btn btn-primary btn-style-2 Centered" href="<?php echo site_url('signup'); ?>">Sign up</a> -->
                    </form>
                </div>
                <div id="menu1" class="tab-pane fade">
                    <form id="sign_in" class="sign-in" action="<?= base_url('signup') ?>" method="post">
                        <!-- <h5 class="Login-title">Sign Up</h5> -->
                        <div class="row m-3">
                            <div class="col-md-6 col-sm-12 col-xs-12">
                                <div class="mb-3">
                                    <input type="text" class="form-control input-style" name="firstname" id="firstname"
                                        placeholder="first name" value="<?php echo set_value('firstname'); ?>">
                                    <?php if (isset($validation)): ?>
                                        <div style="color:red">
                                            <?= $validation->showError('firstname') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <input type="text" class="form-control input-style" name="tenantname"
                                        id="tenantname" placeholder="Tenant Details"
                                        value="<?php echo set_value('tenantname'); ?>">
                                    <?php if (isset($validation)): ?>
                                        <div style="color:red">
                                            <?= $validation->showError('tenantname') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <input type="email" placeholder="Email Address" class="form-control input-style"
                                        name="email" id="email" value="<?php echo set_value('email'); ?>">
                                    <?php if (isset($validation)): ?>
                                        <div style="color:red">
                                            <?= $validation->showError('email') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <input type="password" class="form-control input-style" placeholder="Password"
                                        name="password" id="password">
                                    <?php if (isset($validation)): ?>
                                        <div style="color:red">
                                            <?= $validation->showError('password') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12 col-xs-12">
                                <div class="mb-3">
                                    <input type="text" class="form-control input-style" name="lastname" id="lastname"
                                        placeholder="last name" value="<?php echo set_value('lastname'); ?>">
                                    <?php if (isset($validation)): ?>
                                        <div style="color:red">
                                            <?= $validation->showError('lastname') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <input type="text" class="form-control input-style" name="username" id="username"
                                        placeholder="username" value="<?php echo set_value('username'); ?>">
                                    <?php if (isset($validation)): ?>
                                        <div style="color:red">
                                            <?= $validation->showError('username') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <input type="text" class="form-control input-style" name="phone_no" id="phone_no"
                                        placeholder="Phone No." value="<?php echo set_value('phone_no'); ?>">
                                    <?php if (isset($validation)): ?>
                                        <div style="color:red">
                                            <?= $validation->showError('phone_no') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <input type="password" placeholder="Confirm Password"
                                        class="form-control input-style" name="confirmpassword" id="confirmpassword">
                                    <?php if (isset($validation)): ?>
                                        <div style="color:red">
                                            <?= $validation->showError('confirmpassword') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row m-3">
                            <button type="submit" class="btn btn-primary btn-style Centered mb-3">Submit</button>
                            <a class="btn btn-primary btn-style-2 Centered" href="<?php echo site_url('login'); ?>">Back
                                to Login</a>
                        </div>
                    </form>
                </div>
                <!-- <div id="menu2" class="tab-pane fade">
                <h3>Menu 2</h3>
                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
                </div>
                <div id="menu3" class="tab-pane fade">
                <h3>Menu 3</h3>
                <p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
                </div> -->
            </div>
        </div>

    </div>



</div>






<?= $this->endSection() ?>