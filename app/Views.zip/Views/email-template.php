<html>

<head>
    <title>Email Using a Custom Template</title>
</head>

<body>
    <h3>Test Mail - Support</h3>
    <p>
        This is a sample message sent by Online Web Tutor Support using a custom template.
    </p>
    <p>
        Thanks,<br />Online Web Tutor
    </p>
</body>

</html>