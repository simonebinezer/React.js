<?= $this->extend("layouts/app") ?>

<?= $this->section("body") ?>
<?php include APPPATH . 'Views/layouts/sidebar.php'; ?>
<?php echo script_tag('js/jquery.min.js'); ?>
<style>
  .edit-sur {
    background: none !important;
    border: 1px solid #092c4c;
  }

  .edit-sur:hover {
    background: #00000017 !important;
    border: 1px solid #092c4c;
  }

  .del-sur {
    background: none !important;
    border: 1px solid #092c4c;
  }

  .del-sur:hover {
    background: #00000017 !important;
    border: 1px solid #092c4c;
  }

  .table-striped>tbody>tr:nth-of-type(odd)>* {
    --bs-table-color-type: none;
    --bs-table-bg-type: none;
  }

  .sur-lis-bd {
    border-width: 0px !important;
  }

  .sur-lis-bd td {
    border-width: 0px 0px 1px 0px !important;
    padding: 20px 30px;
    border-bottom: 1px solid #cae3ff;
    background: none;
  }

  .sur-lis-bd th {
    border-width: 0px 0px 1px 0px !important;
    padding: 20px 30px;
    border-bottom: 1px solid #cae3ff;
    background: none;
  }

  .table-bordered {
    padding: 20px;
    background: #fff;
    border-radius: 20px;
  }

  .crt-sur {
    border-radius: 5px;
    background: #092C4C;
    border: 0px;
  }

  .crt-sur:hover {
    border-radius: 5px;
    background: #092C4C;
    border: 1px solid #092C4C;
  }
</style>
<section class="home">
  <div class="container">
    <!-- Breadcrumbs-->
    <!-- <?php include APPPATH . 'Views/layouts/breadcrumb.php'; ?> -->
    <!-- Page Content -->
    <!-- <h1>Survey List</h1>
    <hr> -->

    <?php if (session()->getFlashdata('response') !== NULL) : ?>
      <p style="color:green; font-size:18px;" align="center">
        <?php echo session()->getFlashdata('response'); ?>
      </p>
    <?php endif; ?>
    <div class="row ">
      <div class="col-xl-6 col-lg-6 col-md-6">
        <div class="mb-5">
          <h1>Survey List</h1>
        </div>
      </div>
      <div class="col-xl-6 col-lg-6 col-md-6">
        <div class="text-center mb-5"><a class="btn btn-primary crt-sur float-end" href="<?php echo site_url('createSurvey'); ?>">Create Survey</a>
        </div>
      </div>
    </div>

    <?php if (!empty($surveyList)) { ?>
      <table class="table mt-6 table-striped table-bordered">
        <thead>
          <tr class="sur-lis-bd">
            <th scope="col">S.No</th>
            <th scope="col">Survey campaign Name</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($surveyList as $surveyData) { ?>
            <tr class="sur-lis-bd">
              <td scope="row">
                <?php echo $surveyData['campaign_id']; ?>
              </td>
              <td>
                <?php echo stripslashes($surveyData['campaign_name']); ?>
                <?php if ($surveyData['status'] == 0) { ?><p style="color: red;font-size: 12px;">* This survey is already in progress you cannot edit or delete</p><?php } ?>
              </td>
              <td>
                  <a class="btn btn-primary edit-sur" href="<?php echo site_url('editsurvey/' . $surveyData['campaign_id']); ?>" <?php if ($surveyData['status'] == 0) { ?>style="pointer-events: none;"<?php } ?>> <img src="<?php echo base_url(); ?>images/icons/Create.png" class="img-centered img-fluid"></a>
                  <a class="btn btn-primary del-sur" href="<?php echo site_url('deletesurvey/' . $surveyData['campaign_id']); ?>" <?php if ($surveyData['status'] == 0) { ?>style="pointer-events: none;"<?php } ?>> <img src="<?php echo base_url(); ?>images/icons/Remove.png" class="img-centered img-fluid"></a>
              </td>

            </tr>

          <?php } ?>
        </tbody>

      </table>
    <?php } else { ?>
      <div class="text-center">
        <p class="fs-3"> <span class="text-danger">Oops!</span>No records found.</p>
      </div>
    <?php } ?>
  </div>
</section>
<!-- <script>
   $(document).ready(function(){ 
    .addEventListener('submit', function(e) {
function showAlert(){
  $('#info').html="error";
}

    });
  </script> -->
<?= $this->endSection() ?>