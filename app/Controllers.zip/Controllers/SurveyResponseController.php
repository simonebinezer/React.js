<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\AnswerListModel;
use App\Models\UserModel;
use App\Models\TenantModel;
use App\Models\QuestionModel;
use App\Models\SurveyModel;
use App\Models\ExternalcontactsModel;
use App\Models\CreatecontactsModel;
use App\Models\SurveyResponseModel;
use DateInterval;
use \Exception;

class SurveyResponseController extends BaseController
{
    public function index()
    {
        $selectedSurvey = null;
        $getfullcollection = array();
        $surveyList = array();

        $tenantId = ($this->request->getGet("tenantId") != '') ? $this->request->getGet("tenantId") :  session()->get('tenant_id');
        $selectedSurveyId = $this->request->getMethod() == 'post' ? $this->request->getPost("surveyid") : 0;

        $model = new AnswerListModel();
        $defaultAnswerList = $model->find();

        $model = new QuestionModel();
        $defaultQuestions = $model->find();

        $model = new TenantModel();
        //echo($model->db->database);
        $getTenantdata = $model->findall();
        if ($tenantId > 1) {
            $model = new TenantModel();
            $tenant = $model->where('tenant_id', $tenantId)->first();
            $dbname = "nps_" . $tenant['tenant_name'];

            //$model->db->setDatabase($dbname);
            //echo($model->db->database);
            $db = db_connect();
            $db->query('USE ' . $dbname);
        }
        $selectTenant = $tenantId;
        $userId = array();
        $model = new UserModel();
        $userlist = $model->where('tenant_id', $tenantId)->findall();
        foreach ($userlist as $userarray) {
            array_push($userId, $userarray['id']);
        }
        $surveyResponseList = array();

        //get suvery List
        $model = new SurveyModel();
        $surveyList = $model->whereIn('user_id', $userId)->where('status', '0')->find();
        if (count($surveyList) > 0) {
            if ($selectedSurveyId == 0) {
                $lastSurvey = end($surveyList);
                $selectedSurveyId = $lastSurvey['campaign_id'];
                $selectedSurvey = $lastSurvey;
            } else {
                foreach ($surveyList as $survey) {
                    if ($survey['campaign_id'] == $selectedSurveyId) {
                        $selectedSurvey = $survey;
                        break;
                    }
                }
            }
        }

        if ($selectedSurveyId > 0) {
            //get the survey response of the surveyId
            $model = new SurveyResponseModel();
            $multiClause = array('campaign_id' => $selectedSurveyId);
            $surveyResponseList = $model->whereIn('user_id', $userId)->where($multiClause)->orderBy('created_at', 'DESC')->find();

            foreach ($surveyResponseList as $key => $surveyResponse) {

                //get question data
                //$model = new QuestionModel();
                $question_id = [$surveyResponse['question_id'], $surveyResponse['question_id2']];
                //$getquestionData = $model->whereIn('question_id', $question_id)->find();

                $questionData = array();

                //bind the placeholder name
                $defaultQuestions[0]["question_name"] = str_replace("[Our Company/Product/Service Name]", $selectedSurvey["placeholder_name"], $defaultQuestions[0]["question_name"]);
                array_push($questionData, $defaultQuestions[0], $defaultQuestions[$question_id[1] - 1]);

                //get answer data
                $answer_id2 = $surveyResponse['answer_id2'];
                $answer_id2Array = explode(',', $answer_id2);
                $model = new AnswerListModel();
                $answer2_List = $model->whereIn('answer_id', $answer_id2Array)->find();

                foreach ($answer_id2Array as $key => $value) {
                    foreach ($defaultAnswerList as $key2 => $value2) {
                        if ($value == $value2['answer_id']) {
                            array_push($answer2_List, $value2);
                            break;
                        }
                    }
                }

                $answer2_Str = "";
                $answer2_names = array();
                foreach ($answer2_List as $key2 => $answer2) {
                    array_push($answer2_names, $answer2["answer_name"]);
                }
                $answer2_Str = implode(",", $answer2_names);

                //get external contacts
                $model = new ExternalcontactsModel();
                $getcontactData = $model->where('email_id', $surveyResponse['email'])->first();

                $model = new CreatecontactsModel();
               $res= $model->where('survey_id',$surveyResponse['campaign_id'])->like('email_list',$surveyResponse['email'],'both')->first();
                //echo($model->db->database);
                //$sendDate=strtotime($res['created_at']);
                //$respondedDate=strtotime($surveyResponse['created_at']);
                $sendDate =new \DateTime($res['created_at']);
                $respondedDate=new \DateTime($surveyResponse['created_at']);
                $timeInterval=date_diff($sendDate, $respondedDate);
                
                $getSurveycollection = [
                    "survey_id" => $surveyResponse['id'],
                    "campaign_id" => $surveyResponse['campaign_id'],
                    "ip_details" => $surveyResponse['ip_details'],
                    "location" => $surveyResponse['location'],
                    "answer_id1" => $surveyResponse['answer_id'],
                    "answer_id2" => $answer2_Str,
                    "created_at" => $surveyResponse['created_at'],
                    "timeInterval"=>$timeInterval,
                    "questiondata" => $questionData,
                    "userdata" => $getcontactData

                ];
                array_push($getfullcollection, $getSurveycollection);
            }
        }

        return view('admin/surveyresponselist', ['getSurveyData' =>  $getfullcollection, "getsurveylist" => $surveyList, "selectsurvey" => $selectedSurveyId, "getTenantdata" => $getTenantdata, "selectTenant" => $selectTenant]);
    }
    public function getCustomerList()
    {
        $userslist = null;
        if (session()->get('tenant_id') == 1) {
            $model = new ExternalcontactsModel();
            $condition = array('status' => 1);
            //$userslist = $model->where('created_by', session()->get('id'))->find();
            $userslist = $model->where($condition)->find();
        } else {
            $model = new TenantModel();
            $tenant = $model->where('tenant_id', session()->get('tenant_id'))->first();
            $dbname = "nps_" . $tenant['tenant_name'];
            //new DB creation for Tenant details
            $db = db_connect();
            $db->query('USE ' . $dbname);
            $multiClause3 = "SELECT * FROM " . $dbname . ".nps_external_contacts  WHERE `nps_external_contacts`.`status` = " . 1;
            $listuser = $db->query($multiClause3);
            if (count($listuser->getResultArray()) > 0) {
                $userslist =  $listuser->getResultArray();
            }
        }
        return view('admin/getCustomerlist', ["userslist" => $userslist]);
    }
}
