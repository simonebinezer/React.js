<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ExternalcontactsModel;
use App\Models\TenantModel;




class CustomerController extends BaseController
{

    public function UpdateCustomerDetails()
    { $data = [];
       $postData= $this->request->getPost();
          
          #$model->update()->update()
          if ($this->request->getMethod() == 'post') {
            $rules = [
                'first_name' => 'required|alpha',
                'last_name' => 'required|alpha',
                'contact' => 'required|numeric|exact_length[10]|validateCustomerContact[contact]',
                'email' => 'required|min_length[6]|max_length[50]|valid_email|validateCustomerEmail[email]'
            ];
            $errors = [
               
                'first_name' => [
                    'required' => 'First Name is required.',
                ],
                'last_name' => [
                    'required' => 'Last Name is required.',
                ],
                'contact' =>
                [
                    'validateCustomerContact' =>'Contact is already available.'
                ],
                
                'email' => [
                    'valid_email' => 'Please check the Email field. It does not appear to be valid.',
                    'validateCustomerEmail' => 'Email Address is already available.',
                ],
                
            ];
            if (!$this->validate($rules, $errors)) {
                $object=new SurveyResponseController();
                $userslist=$object->getCustomerList();
                $a=$this->validator->getErrors();
                return view('admin/getCustomerlist', [
                    "validation" => $this->validator,
                    "Function"=>"EDIT",
                    "Data"=>json_encode($postData),
                    ["userslist" => $userslist  ]
                ]);
            }
            else{

                 $postData=$this->request->getPost();
                 $model=new ExternalcontactsModel();
                 $data = [
                    "id"=>$postData['E_Id'],
                    "name" => $postData['first_name']." ".$postData['last_name'],
                    "firstname" => $postData['first_name'],
                    "lastname" => $postData['last_name'],
                    "email_id" =>  $postData['email'],
                    "contact_details" =>  $postData['contact'],
                    "created_by"=>session()->get('id')
                ];
                if(session()->get('tenant_id') == 1)
                {
                    $result = $model->update($data['id'],$data);
                }
                else
                {

                    $model = new TenantModel();
                    $tenant = $model->where('tenant_id', session()->get('tenant_id'))->first();
                    $dbname = "nps_".$tenant['tenant_name'];     
                    //new DB creation for Tenant details
                    $db = db_connect();
                    $db->query('USE '.$dbname);
                    foreach($data as $key=>$val) 
                    {
                        $cols[] = "$key = '$val'";
                    }
                    $query ="UPDATE  ".$dbname.".nps_external_contacts SET ". implode(',' , $cols) ." WHERE nps_external_contacts.id = '". $data['id']."'";
                    $db->query($query);
                    $db->close();
                }
                return redirect()->to(base_url('getCustomerData'));
            }
        }
    }
    public function InsertCustomerDetails()
    {
        if ($this->request->getMethod() == 'post') {
            $postData=$this->request->getPost();
            $rules = [
                'first_name' => 'required|alpha',
                'last_name' => 'required|alpha',
                'contact' => 'required|numeric|exact_length[10]|validateCustomerContact[contact]',
                'email' => 'required|min_length[6]|max_length[50]|valid_email|validateCustomerEmail[email]'
            ];
            $errors = [
                
                'first_name' => [
                    'required' => 'First Name is required.',
                ],
                'last_name' => [
                    'required' => 'Last Name is required.',
                ],
                'contact' =>
                [
                    'validateCustomerContact' =>'Contact is already available'
                ],
                'email' => 
                [
                    'valid_email' => 'Please check the Email field. It does not appear to be valid.',
                    'validateCustomerEmail' => 'Email Address is already available.',
                ],
                
            ];
            if (!$this->validate($rules, $errors)) {
                $object=new SurveyResponseController();
                $userlist=$object->getCustomerList();
                return view('admin/getCustomerlist', [
                    "validation" => $this->validator,
                    "Function"=>"ADD",
                    "Data"=>json_encode($postData),
                    ["userslist" => $userlist  ]
                ]);
            }
            else{

                 
                 $model=new ExternalcontactsModel();
                 $data = [
                    "name" => $postData['first_name']." ".$postData['last_name'] ,
                    "firstname" => $postData['first_name'],
                    "lastname" => $postData['last_name'],
                    "email_id" =>  $postData['email'],
                    "contact_details" =>  $postData['contact'],
                    "created_by"=>session()->get('id')
                ];
                if(session()->get('tenant_id') == 1)
                {
                    $result = $model->insert($data,true);
                }
                #$db = db_connect();        
                #$userId = $db->insertID();
                else
                {

                    $model = new TenantModel();
                    $tenant = $model->where('tenant_id', session()->get('tenant_id'))->first();
                    $dbname = "nps_".$tenant['tenant_name'];     
                    //new DB creation for Tenant details
                    $db = db_connect();
                    $db->query('USE '.$dbname);
                    $key = array_keys($data); 
                    $values = array_values($data); 
                    $query ="INSERT INTO ".$dbname.".nps_external_contacts  ( ". implode(',' , $key) .") VALUES('". implode("','" , $values) ."')";
                    $db->query($query);
                    $db->close();
                }
                return redirect()->to(base_url('getCustomerData'));

            }
        }
    }

    public function DeleteCustomer()
    {   
        $postData=$this->request->getPost();
        $model=new ExternalcontactsModel();
        $data = ['status'=>'0'];
        if(session()->get('tenant_id') == 1)
        {
            $result = $model->update($postData['Id'],$data);
        }
        else
        {
            $model = new TenantModel();
            $tenant = $model->where('tenant_id', session()->get('tenant_id'))->first();
            $dbname = "nps_".$tenant['tenant_name'];     
            //new DB creation for Tenant details
            $db = db_connect();
            $db->query('USE '.$dbname);
            $query ="UPDATE  ".$dbname.".nps_external_contacts SET nps_external_contacts.status = '". $data['status']."' WHERE nps_external_contacts.id = '". $postData['Id']."'";
            $db->query($query);
            $db->close();
        }
        return redirect()->to(base_url('getCustomerData'));
    }

    // public function UploadFileCustomer()
    // { 

    // }

    public function UploadFileCustomer()
    { 
        $rules=[
            'formData' => 'uploaded[formData]|max_size[formData,2048]|ext_in[formData,csv]'
        ];
        $errors=
        [
            'formData'=>
            [
                'max_size'=>'uploaded file size is more than 2mb',
                'ext_in'=> "uploaded file is not a csv file"
            ]
            ];
        $input = $this->validate($rules,$errors);
        if (!$input) {
            $data = $this->validator->getErrors();
            echo json_encode(['success'=>false,'validation'=> $data, 'csrf' => csrf_hash()]);   
        }
        else 
        {
            if($file = $this->request->getFile('formData')) {
                if ($file->isValid() && ! $file->hasMoved()) {                    
                    $newName = $file->getRandomName();
                    $file->move('../public/csvfile', $newName);
                    $file = fopen("../public/csvfile/".$newName,"r");
                    $i = 0;
                    $numberOfFields = 5;
                    $csvArr = array();
                    while (($filedata = fgetcsv($file, 1000, ",")) !== FALSE) {
                        $num = count($filedata);
                        if($i > 0 && $num == $numberOfFields){ 
                            $csvArr[$i]['name'] = $filedata[0];
                            $csvArr[$i]['firstname'] = $filedata[1];
                            $csvArr[$i]['lastname'] = $filedata[2];
                            $csvArr[$i]['contact'] = $filedata[3];
                            $csvArr[$i]['email'] = $filedata[4];
                        }
                        $i++;
                    }
                    fclose($file);
                    $count = 0;
                    $emaillist= array();
                    foreach($csvArr as $exportData){
                        $validateEmail = $this->Check_ContactAndEmail($exportData["email"],$exportData["contact"]);
                        if($validateEmail) 
                        {
                            $tenant  = 
                            [
                                "tenant_id" => session()->get('tenant_id'),
                                "tenant_name" =>  session()->get('tenant_name')
                            ];
                            $data = 
                            [
                                "name" => $exportData["name"],
                                "firstname" => $exportData["firstname"],
                                "lastname" => $exportData["lastname"],
                                "contact_details" => $exportData["contact"],
                                "email_id" => $exportData["email"],
                                "created_by" => session()->get('id')
                            ];
                            if($tenant['tenant_id'] == 1) 
                            {
                                $this->createContact($data); 
                            } 
                            else 
                            {
                                $this->tenantCreateContact($data, $tenant);
                            }                                             
                            $count++;
                        }
                    }
                }
            }
            echo json_encode(['success'=> true, 'csrf' => csrf_hash(), "count" =>  $count]);   
        }

    }

    public function Check_ContactAndEmail(string $emailid,$contact){
        if(session()->get('tenant_id') > 1 ){
            $dbname = "nps_".session()->get('tenant_name');     
            //new DB creation for Tenant details
            $db = db_connect();
            $db->query('USE '.$dbname);
            $new_db_select ="SELECT * FROM ".$dbname.".nps_external_contacts  WHERE (`nps_external_contacts`.`email_id` = '". $emailid."' OR nps_external_contacts.contact_details = '". $contact."') and nps_external_contacts.status = ". 1;
            $result = $db->query($new_db_select);
            if(count($result->getResult()) > 0) {
                return false;
            }
            return true;
        }else {
            $model = new ExternalcontactsModel();
             $contactlist=  $model->where("status='1' AND (email_id='$emailid' OR contact_details= $contact)")->first();
            if($contactlist){
                return false;
            }
            return true;
        }
    }
    public function createContact($exportData)
    {
        $model = new ExternalcontactsModel();
        $result = $model->insertBatch([$exportData]);                 
    }
    public function tenantCreateContact($exportData, $tenantdata) {
        $dbname = "nps_".$tenantdata['tenant_name'];     
        //new DB creation for Tenant details
        $db = db_connect();
        $db->query('USE '.$dbname);
        $key = array_keys($exportData); 
        $values = array_values($exportData); 
        $new_db_insert_user ="INSERT INTO ".$dbname.".nps_external_contacts ( ". implode(',' , $key) .") VALUES('". implode("','" , $values) ."')";
        $db->query($new_db_insert_user);
    }
}